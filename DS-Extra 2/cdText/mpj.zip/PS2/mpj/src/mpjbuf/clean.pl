#!/usr/bin/perl

# File         : generate.pl
# Author       : Bryan Carpenter
# Created      : Thu Jul 15 10:44:32 BST 2004
# Revision     : $Revision: 1.3 $
# Updated      : $Date: 2005/08/16 21:44:13 $

unlink "Buffer.java" ;
unlink "RawBuffer.java" ;
unlink "NIOBuffer.java" ; 
